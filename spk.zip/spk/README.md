# sistempendukungkeputusan-ahp
Indonesia : Sistem pendukung keputusan menggunakan metode ahp, dibuat untuk memenuhi tugas perkuliahan matakuliah Sistem Pendukung Keputusan

English : The decision support system uses the ahp method, made to fulfill the college assignments for the decision support system

Website Link : http://kevinmalikfajar.alwaysdata.net/sistempendukungkeputusan-ahp
