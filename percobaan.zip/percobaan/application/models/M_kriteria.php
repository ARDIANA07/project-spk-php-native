<?php

class M_kriteria extends CI_Model{


   // mencari ID kriteria
// berdasarkan urutan ke berapa (C1, C2, C3)
    function getKriteriaID($no_urut) {
	include('config.php');
	$query  = "SELECT id FROM kriteria ORDER BY id";
	$result = mysqli_query($koneksi, $query);

	while ($row = mysqli_fetch_array($result)) {
		$listID[] = $row['id'];
	}

	return $listID[($no_urut)];
    }

    // mencari nama kriteria
    function getKriteriaNama($no_urut) {
        include('config.php');
        $query  = "SELECT nama FROM kriteria ORDER BY id";
        $result = mysqli_query($koneksi, $query);

        while ($row = mysqli_fetch_array($result)) {
            $nama[] = $row['nama'];
        }

        return $nama[($no_urut)];
    }

    // mencari priority vector kriteria
        function getKriteriaPV($id_kriteria) {
            include('config.php');
            $query = "SELECT nilai FROM pv_kriteria WHERE id_kriteria=$id_kriteria";
            $result = mysqli_query($koneksi, $query);
            while ($row = mysqli_fetch_array($result)) {
                $pv = $row['nilai'];
            }

            return $pv;
        }

}