<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kriteria extends CI_Controller {

	public function index()
	{
		
		$this->load->view('alternatif');
	}
}
    // mencari ID alternatif
    // berdasarkan urutan ke berapa (A1, A2, A3)
    function getAlternatifID($no_urut) {
        include('config.php');
        $query  = "SELECT id FROM alternatif ORDER BY id";
        $result = mysqli_query($koneksi, $query);

        while ($row = mysqli_fetch_array($result)) {
            $listID[] = $row['id'];
        }

        return $listID[($no_urut)];
    }

    // mencari nama alternatif
        function getAlternatifNama($no_urut) {
            include('config.php');
            $query  = "SELECT nama FROM alternatif ORDER BY id";
            $result = mysqli_query($koneksi, $query);

            while ($row = mysqli_fetch_array($result)) {
                $nama[] = $row['nama'];
            }

            return $nama[($no_urut)];
        }

        // mencari priority vector alternatif
            function getAlternatifPV($id_alternatif,$id_kriteria) {
                include('config.php');
                $query = "SELECT nilai FROM pv_alternatif WHERE id_alternatif=$id_alternatif AND id_kriteria=$id_kriteria";
                $result = mysqli_query($koneksi, $query);
                while ($row = mysqli_fetch_array($result)) {
                    $pv = $row['nilai'];
                }

                return $pv;
            }

            // mencari jumlah alternatif
                function getJumlahAlternatif() {
                    include('config.php');
                    $query  = "SELECT count(*) FROM alternatif";
                    $result = mysqli_query($koneksi, $query);
                    while ($row = mysqli_fetch_array($result)) {
                        $jmlData = $row[0];
                    }

                    return $jmlData;
                }
                // menambah data kriteria / alternatif
                    function tambahData($tabel,$nama) {
                        include('config.php');

                        $query 	= "INSERT INTO $tabel (nama) VALUES ('$nama')";
                        $tambah	= mysqli_query($koneksi, $query);

                        if (!$tambah) {
                            echo "Gagal mmenambah data".$tabel;
                            exit();
                        }
                    }

                    // hapus alternatif
                function deleteAlternatif($id) {
                    include('config.php');

                    // hapus record dari tabel alternatif
                    $query 	= "DELETE FROM alternatif WHERE id=$id";
                    mysqli_query($koneksi, $query);

                    // hapus record dari tabel pv_alternatif
                    $query 	= "DELETE FROM pv_alternatif WHERE id_alternatif=$id";
                    mysqli_query($koneksi, $query);

                    // hapus record dari tabel ranking
                    $query 	= "DELETE FROM ranking WHERE id_alternatif=$id";
                    mysqli_query($koneksi, $query);

                    $query 	= "DELETE FROM perbandingan_alternatif WHERE alternatif1=$id OR alternatif2=$id";
                    mysqli_query($koneksi, $query);
                }

                    // memasukkan nilai priority vektor alternatif
                    function inputAlternatifPV ($id_alternatif,$id_kriteria,$pv) {
                        include ('config.php');

                        $query  = "SELECT * FROM pv_alternatif WHERE id_alternatif = $id_alternatif AND id_kriteria = $id_kriteria";
                        $result = mysqli_query($koneksi, $query);

                        if (!$result) {
                            echo "Error !!!";
                            exit();
                        }

                        // jika result kosong maka masukkan data baru
                        // jika telah ada maka diupdate
                        if (mysqli_num_rows($result)==0) {
                            $query = "INSERT INTO pv_alternatif (id_alternatif,id_kriteria,nilai) VALUES ($id_alternatif,$id_kriteria,$pv)";
                        } else {
                            $query = "UPDATE pv_alternatif SET nilai=$pv WHERE id_alternatif=$id_alternatif AND id_kriteria=$id_kriteria";
                        }

                        $result = mysqli_query($koneksi, $query);
                        if (!$result) {
                            echo "Gagal memasukkan / update nilai priority vector alternatif";
                            exit();
                        }

                    }

?>